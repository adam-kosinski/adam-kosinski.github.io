/*<<<<<<<<<< SET UP FIELD >>>>>>>>>>>>>>>>>>>>>>>>>>*/

//get references
var field = document.getElementById("field");
var snitch = document.getElementById("snitch");
var clickRegion = document.getElementById("clickRegion");
var leftWing = document.getElementById("leftWing");
var rightWing = document.getElementById("rightWing");


//deal with field size - put below scalar declaration later
function resizeField(){
	field.style.height = window.innerHeight + "px";
	field.style.width = window.innerWidth + "px";
}
resizeField(); //set field to intial window dimensions


//deal with snitch size
var snitchSize = 50; //diameter of ball part of snitch in px

snitch.style.width = snitchSize+"px";
snitch.style.height = snitchSize+"px";
clickRegion.style.width = snitchSize+"px";
clickRegion.style.height = snitchSize+"px";
clickRegion.style.borderRadius = snitchSize/2 + "px";

leftWing.style.width = snitchSize + 2*(snitchSize*1.25) + "px" //width is ball plus twice the established 'width' of the wing
leftWing.style.left = -(snitchSize*1.25)+"px" //offset it by wing width
rightWing.style.width = snitchSize + 2*(snitchSize*1.25) + "px"
rightWing.style.left = -(snitchSize*1.25)+"px"

/*<<<<<<<<<<<<<<< SNITCH MOVEMENT >>>>>>>>>>>>>>>>>>*/
var isSnitchCaught = false;
var fps = 10;
var scalar = 6; //px per frame, essentially scaling factor b/c default is to move snitch one pixel, dilate the screen to move more per frame

snitch.style.transitionDuration = 1000/fps + "ms";

var topOffset = 30;
var leftOffset = 30;
snitch.style.top = topOffset*scalar + "px";
snitch.style.left = leftOffset*scalar + "px";

//mouse coords
var mX;
var mY;

var maxXOffset = Math.floor((window.innerWidth - snitchSize)/scalar); /////////////////////////////// DEAL W/ CALCULATING THIS - 'SNITCH SIZE' WON'T REPRESENT A SQUARE
var maxYOffset = Math.floor((window.innerHeight - snitchSize)/scalar);

var Dirs /*directions*/ = [[1,0],[1,1],[0,1],[-1,1],[-1,0],[-1,-1],[0,-1],[1,-1]]; //[x,y], array rotates clockwise (to right) from standard position
var cDir = Math.floor(Math.random()*8); //current direction


/*<<<<<<<<<<<<<<<<<<<< SNITCH MOVEMENT CONTROL >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.*/
var mode = "idle"; //'idle' or one of the runaway modes
var runawayModes = ["straight","spiralLeft","spiralRight"];
var escapeWallFrom = 2; //if snitch this many or less px from wall during a runaway mode, should do escape wall mode
var escapeWallTo = 10 //if snitch this many pixels away from wall during a runaway mode, should exit escape wall mode

function moveSnitch(){ //interval function, called periodically over time
	if(isSnitchCaught){return}
	
	//examine distance to mouse, set mode accordingly
	if(mX && mY){sizeUpDistance()}
	
	//pick a direction; change cDir
	cDir = pickDirection();
	
	console.log("cDir:"+cDir);
	
	//change style (display)
	snitch.style.left = (leftOffset + Dirs[cDir][0])*scalar + "px";
	snitch.style.top = (topOffset + Dirs[cDir][1])*scalar + "px";
	
	//change variables
	leftOffset += Dirs[cDir][0];
	topOffset += Dirs[cDir][1];
	
	//increment runaway counter if running away
	if(mode !== "idle"){runawayCounter++}
	
	setTimeout(moveSnitch,1000/fps);
}

moveSnitch();


function handleMouseMove(e){
	mX = e.pageX;
	mY = e.pageY;
}
field.addEventListener("mousemove",handleMouseMove);


function distanceToMouse(x,y){ //x and y based on non-scaled coordinates (leftOffset and topOffset are also based on non-scaled coords)
	var dx = (x*scalar)+(snitchSize/2) - mX; //snitch coord minus mouse coord
	var dy = (y*scalar)+(snitchSize/2) - mY;
	
	return Math.sqrt(dx*dx + dy*dy); //pythag/distance formula
}

function minDistToWall(x,y){ //x and y are non-scaled coords
	var dists = [
		y, //top
		x, //left
		maxXOffset-x, //right
		maxYOffset-y]; //down
	
	//sort numerically ascending
	dists.sort(function(a,b){return (a-b)});
	
	return dists;
}


var runawayCounter = 0; //number of frames that current runaway mode has been used, incremented in moveSnitch() if mode !== 'idle'
var runawayLength = 0; //intended number of frames to use current runaway mode

function sizeUpDistance(){
	var dist = distanceToMouse(leftOffset, topOffset);
	
	if(dist < 200){ //runaway mode triggered
		fps = 30;
		snitch.style.transitionDuration = 1000/fps + "ms"; //update animation to match new fps
		
		wallDist = minDistToWall(leftOffset,topOffset)[0];
		if(wallDist <= escapeWallFrom || (mode === "escapeWall" && wallDist <= escapeWallTo)){
			mode = "escapeWall";
			console.log("escaping * * * * * * * * * * * * * * * ");
		} else if(runawayCounter === runawayLength || mode === "escapeWall"){
			//pick new runaway mode
			mode = runawayModes[Math.floor(Math.random()*(runawayModes.length-1))];
			console.log(mode)
			//reset counter to 0
			runawayCounter = 0;
			
			//pick semi-random amount of frames -> runawayLength
			runawayLength = 30
		}
		//console.log("Close proximity ------------------" + Math.floor(dist));
	} else {
		fps = 10;
		snitch.style.transitionDuration = 1000/fps + "ms";
		mode = "idle";
		runawayCounter = 0;
		runawayLength = 0;
		//console.log("Idle mode >>>>>>>>>>>>>>>>>>>>>>>>" + Math.floor(dist));
	}
}

/* <<<<<<<<<<<< PICK DIRECTION STUFF (INCLUDES MOVEMENT ALGORITHMS) >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.*/
var priDir = []; //priority directions, updated each frame based on current movement algorithm, will contain same dirs as posDir
function evalPriDir(){ //returns lowest-index (highest priority) valid direction in priDir
	for(var i=0; i<3; i++){
		if(isDirValid(priDir[i])){return priDir[i]}
	}
}

function pickDirection(){
		//determine possible directions, indexes - 0:left, 1:same, 2:right
	var posDir = [];
	posDir.push(cDir-1 < 0 ? 7 : cDir-1);   //turn left
	posDir.push(cDir);						//continue straight
	posDir.push(cDir+1 > 7 ? 0 : cDir+1);   //turn right
	//console.log("posDir for below cDir: "+posDir);
	
	/*RUNAWAY MODES*/
	if(mode === "straight"){
		//try each possible direction, determine which one is farthest from mouse, use that one
		var maxDist = 0;
		var maxIndex;
		
		for(var i=0; i<3; i++){
			if(!isDirValid(posDir[i])){continue} //don't count invalid directions
			
			let dist = distanceToMouse(leftOffset+Dirs[posDir[i]][0], topOffset+Dirs[posDir[i]][1]);
			if(dist > maxDist){
				maxDist = dist;
				maxIndex = i;
			}
		}
		
		return posDir[maxIndex];
	}
	if(/^spiral/.test(mode)){ //if begins w/ 'spiral'
		var vrDir = mode === "spiralLeft" ? posDir[0]: posDir[2]; //veer direction
		var otherDir = mode === "spiralLeft" ? posDir[2]: posDir[0]; //opposite turning direction to vrDir
		
		var vrDist = distanceToMouse(leftOffset+Dirs[vrDir][0], topOffset+Dirs[vrDir][1]); //veer dist (dist after move one in vrDir)
		var straightDist = distanceToMouse(leftOffset+Dirs[posDir[1]][0], topOffset+Dirs[posDir[1]][1]); //dist after move one in cDir
		var cDist = distanceToMouse(leftOffset, topOffset); //current distance from mouse
		
		//if vrDist is closer to mouse than current position (before move), and is also closer than going straight, make straight the priority
		if(vrDist<cDist && vrDist<straightDist){
			priDir = [posDir[1],vrDir,otherDir];
		} else{
			priDir = [vrDir,posDir[1],otherDir]; //otherwise, make veer direction the priority
		}
	
		return evalPriDir();
	}
	if(mode === "escapeWall"){
			//loop through posDir, determine which is valid and maximizes...
		var currentBestDir;
		var currentBestSum = -Infinity;
		for(var i=0; i<3; i++){
			if(!isDirValid(posDir[i])){continue}
			
			let x = leftOffset + Dirs[posDir[i]][0];
			let y = topOffset + Dirs[posDir[i]][1];
			
			let fnResult = minDistToWall(x,y);
			let distToWall = fnResult[0];
			let distToMouse = distanceToMouse(x,y)/scalar; //distanceToMouse returns scaled coords
			
			let sum = distToWall*distToWall + distToMouse;
			if(sum > currentBestSum){
				currentBestDir = posDir[i];
				currentBestSum = sum;
			}
		}
		
		return currentBestDir;
	}
	
	/*IDLE MODE*/
	if(mode === "idle"){
			//pick random direction
		var pickArray = [0,1,2];
		do{
			var testPick = pickArray.splice(Math.floor(Math.random()*pickArray.length), 1)[0]; //splice out a random element,
																								//FYI: array.splice() returns an array of deleted elements
		} while(!isDirValid(posDir[testPick])); //keep trying if direction isn't valid
		
		return posDir[testPick];
	}
}

function isDirValid(dir){
		//coords (offsets) for testing
	var x = leftOffset;
	var y = topOffset;
	
	//console.log("  isDirValid, dir: "+dir);
		//move one in chosen direction
	x += Dirs[dir][0];
	y += Dirs[dir][1];
	
		//if moving -> land outside of field, not valid
	if(x<0 || x>maxXOffset || y<0 || y>maxYOffset){return false}
	
		//if diagonal movement (more efficient to check before vert/horz. b/c that one requires incrementing a second time)
	if(Math.abs(Dirs[dir][0])===Math.abs(Dirs[dir][1]) && Math.abs(Dirs[dir][1])>0){ //if abs vals of dx and dy are equal and greater than 0
			//determine distances to 2 borders that we are moving towards
		var hDistAway = Dirs[dir][0] < 0 ? x : maxXOffset-x;
		var vDistAway = Dirs[dir][1] < 0 ? y : maxYOffset-y;
		
			//after moved once (which we test did earlier), should have at least 2 units away from one of the borders moving towards
		if(Math.max(hDistAway,vDistAway) < 2){return false}
	}
	
		//if vertical movement
	else if(Math.abs(Dirs[dir][0]) !== Math.abs(Dirs[dir][1])){
			//move testing position a second time in direction
			//if outside after, means first movement ran it headfirst into the wall
		x += Dirs[dir][0];
		y += Dirs[dir][1];
		if(x<0 || x>maxXOffset || y<0 || y>maxYOffset){return false}
	}
	
		//if passed all checks, it's good to go!
	return true;
}


/*<<<<<<<<<<< CATCH SNITCH >>>>>>>>>>>>>>>>>>>>*/
function caughtSnitch(){
	isSnitchCaught = true;
	console.log("Snitch is caught!");
}

clickRegion.addEventListener("click",caughtSnitch);